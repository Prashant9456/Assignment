import { Box } from "@mui/material";
import { useEffect } from "react";
import history from "../Utils/history";

interface CustomProps {
  location?: Location;
}
const PageNotFound = (props: any) => {
  const url = window.location.href;
  const location = url?.split("/")[3]?.toLowerCase();
  useEffect(() => {
    if (location == "login") {
      window.location.reload(); //
    } else if (location == "register") {
      window.location.reload();
    } else if (location == "dashboard" || location == "Dashboard") {
      window.location.reload();
    }
  }, []);

  return <>{/* <Box>404 Page Not Found</Box> */}</>;
};
export default PageNotFound;
