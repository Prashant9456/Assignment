import { getCallParams, makeCall } from "../Service";

export async function getRegister(userDetails: any) {
  try {
    const data1: any = {
      email: userDetails.email,
      password: userDetails.password,
    };
    const callParams = getCallParams("POST", data1);
    const response: any = await makeCall(
      "https://reqres.in/api/register",
      callParams
    );
    return response;
  } catch (error: any) {
    throw error;
  }
}
