import React, { useRef, useState } from "react";
import {
  Box,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  Typography,
} from "@mui/material";
import {
  registerFormField,
  registrationValidation,
} from "./RegisterTypesAndValidation";
import history from "../Utils/history";
import CustomInput from "../Components/CustomInput/CustomInput";
import { isTruthy } from "../Utils/methods";
import CustomButton from "../Components/CustomButton/CustomButton";
import registerStyles from "./RegisterStyle";
import { getRegister } from "./RegisterService";

const Register = () => {
  const classes = registerStyles;
  const emailRegex =
    /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  const siteKey = "6LcfPTQiAAAAAEiV_UD6vAZCy2RkJ1heocnrPFSq";
  const [formFields, setFormFields] = useState(registerFormField);
  const [showPassword, setShowPassword] = useState(false);

  const handleOnChangeInputField = (event: React.ChangeEvent<any>) => {
    setFormFields({
      ...formFields,
      [event.target.name]: {
        ...formFields[event.target.name],
        value: event.target.value,
        error: "",
      },
    });
  };

  const handleKeypress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleRegister();
    }
  };

  const handleRegister = async () => {
    try {
      const user = {
        id: "",
        password: formFields?.pwd?.value,
        name: formFields?.name?.value + " " + formFields?.lastName?.value,

        email: formFields?.email?.value,
      };
      if (
        handleValidation() &&
        emailRegex.test(formFields.email.value) &&
        formFields.email.value.length > 0
      ) {
        await getRegister(user);
        history.push("/login");
      }
    } catch (error: any) {
      alert(error.error);
    }
  };

  const handleValidation = () => {
    const { isValid, errors } = registrationValidation(formFields);
    setFormFields({ ...errors });
    return isValid;
  };

  const loginPage = () => {
    history.push("/login");
  };

  const getRegisterScreen = () => {
    return (
      <Box sx={classes.getRegisterScreen}>
        <Box sx={classes.innerGetLoginBox}>
          <Box sx={{ textAlign: "center" }}>
            <Typography variant="h1" sx={classes.textHeading1}>
              Create Account
            </Typography>
          </Box>
          <Box sx={{ textAlign: "center" }}>
            <Typography sx={classes.heading5} variant="h5">
              Already have an account?{" "}
              <Typography
                sx={classes.heading6}
                component={"span"}
                variant="h5"
                onClick={loginPage}
              >
                Login
              </Typography>
            </Typography>
          </Box>
          <Grid
            container
            sx={classes.formCenter}
            spacing={2}
            mt={{ xl: 2, lg: 0.5, md: 0.5, sm: 0.5, xs: 0.5 }}
          >
            <Grid item xs={5.5}>
              <CustomInput
                required
                label="First Name"
                placeHolder="Enter first name"
                id="name"
                type="text"
                name="name"
                value={formFields.name.value}
                onChange={handleOnChangeInputField}
                customInputClasses={classes.inputStyle}
                customClasses={classes.inputLabel}
                onKeyPress={handleKeypress}
                propsToInputElement={{ maxLength: 20 }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <Typography variant="h6" sx={{ color: "#7A7A7A" }}>
                        {formFields.name.value?.length} / 20
                      </Typography>
                    </InputAdornment>
                  ),
                }}
              />
              {!isTruthy(formFields.name.value) && formFields.name.error && (
                <FormHelperText error>{formFields.name.error}</FormHelperText>
              )}
            </Grid>
            <Grid item xs={5.5}>
              <CustomInput
                required
                label="Last Name"
                placeHolder="Enter last name"
                id="lastName"
                type="text"
                name="lastName"
                value={formFields.lastName.value}
                onChange={handleOnChangeInputField}
                customInputClasses={classes.inputStyle}
                customClasses={classes.inputLabel}
                onKeyPress={handleKeypress}
                propsToInputElement={{ maxLength: 20 }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <Typography
                        variant="h6"
                        sx={{
                          color: "#7A7A7A",
                        }}
                      >
                        {formFields.lastName.value?.length} / 20
                      </Typography>
                    </InputAdornment>
                  ),
                }}
              />
              {!isTruthy(formFields.lastName.value) &&
                formFields.lastName.error && (
                  <FormHelperText error>
                    {formFields.lastName.error}
                  </FormHelperText>
                )}
            </Grid>

            <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
              <CustomInput
                required
                label="Email"
                placeHolder="Enter email address"
                id="email"
                type="email"
                autoComplete={"new-password"}
                propsToInputElement={{ maxLength: 35 }}
                name="email"
                value={formFields.email.value}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <Typography
                        variant="h6"
                        sx={{
                          color: "#7A7A7A",
                        }}
                      >
                        {formFields.email.value?.length} / 35
                      </Typography>
                    </InputAdornment>
                  ),
                }}
                onChange={handleOnChangeInputField}
                customInputClasses={classes.inputStyle}
                customClasses={classes.inputLabel}
                onKeyPress={handleKeypress}
                error={
                  !isTruthy(formFields.email.value) && formFields.email.error
                }
              />
              {!isTruthy(formFields.email.value) && formFields.email.error && (
                <FormHelperText error>{formFields.email.error}</FormHelperText>
              )}
              {!emailRegex.test(formFields.email.value) &&
                formFields.email.value.length > 0 && (
                  <FormHelperText error>
                    Please enter valid email id
                  </FormHelperText>
                )}
            </Grid>

            <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
              <CustomInput
                required
                label="Password"
                placeHolder="••••••••"
                id="password"
                type={showPassword ? "text" : "password"}
                name="pwd"
                autoComplete={"new-password"}
                value={formFields.pwd.value}
                onChange={handleOnChangeInputField}
                customInputClasses={{
                  ...classes.inputStyle,
                  "& input::-ms-reveal": { display: "none" },
                }}
                isPasswordVisible={formFields.pwd.value ? true : false}
                customClasses={classes.inputLabel}
                onKeyPress={handleKeypress}
              />
              {!isTruthy(formFields.pwd.value) && formFields.pwd.error && (
                <FormHelperText error>{formFields.pwd.error}</FormHelperText>
              )}
            </Grid>
            <Grid
              item
              xs={11}
              sm={11}
              md={11}
              lg={11}
              xl={11}
              mt={{ xl: 3, lg: 3, md: 2, sm: 1, xs: 1 }}
            >
              <Box width={"100%"}>
                <CustomButton
                  label="Sign Up"
                  onClick={handleRegister}
                  customClasses={classes.signBtn}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return <Box sx={classes.registerMainWrapper}>{getRegisterScreen()}</Box>;
};

export default Register;
