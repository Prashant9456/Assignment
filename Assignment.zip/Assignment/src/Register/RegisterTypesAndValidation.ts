export const registerFormField = () => {
  return {
    name: {
      value: "",
      error: "",
    },
    lastName: {
      value: "",
      error: "",
    },

    email: {
      value: "",
      error: "",
    },
    pwd: {
      value: "",
      error: "",
    },
  } as any;
};

export const registrationValidation = (registerUserValue: any) => {
  let errors = registerUserValue;
  const name = registerUserValue.name.value;
  const lastName = registerUserValue.lastName.value;
  const email = registerUserValue.email.value;
  const pwd = registerUserValue.pwd.value;
  let isValid = true;
  if (!name) {
    errors.name.error = "Please enter first name";
    isValid = false;
  }
  if (!lastName) {
    errors.lastName.error = "Please enter last name";
    isValid = false;
  }
  if (!email) {
    errors.email.error = "Please enter email";
    isValid = false;
  }
  if (email) {
    const emailRegex =
      /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (!emailRegex.test(email)) {
      errors.email.error = "Please enter valid E-mail";
      isValid = false;
    }
  }
  if (!pwd) {
    errors.pwd.error = "Please enter password";
    isValid = false;
  }
  return { isValid, errors };
};
