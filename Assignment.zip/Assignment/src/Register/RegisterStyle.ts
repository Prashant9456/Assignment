const registerStyles = {
  registerMainWrapper: {
    height: "100%",
    width: "100%",
    marginTop: { xs: "10px", md: "0" },
  },

  inputStyle: {
    borderRadius: "12px",
    width: "100%",
    input: {
      "&:-webkit-autofill": {
        transition: "background-color 5000s ease-in-out 0s !important",
        "-webkit-text-fill-color": "#000 !important",
      },
    },
    // for placeholder style at disbled button
    "& .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input.Mui-disabled": {
      "-webkit-text-fill-color": "#000",
    },
    ".MuiOutlinedInput-notchedOutline": { border: "none" },
    "&.MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "& .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root": {
      color: "#000",
    },
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        color: "#000",
        fontSize: "15px",
        lineHeight: "28px",
      },
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: "38px",
      color: "#000",
      fontColor: "#000",
      fontSize: "14px",
      lineHeight: "1.5715",
    },
  },
  formCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "55vh",
    overflowY: "auto",
    overflowX: "hidden",
    "&::-webkit-scrollbar": {
      display: "none",
    },
  },
  getRegisterScreen: {
    backgroundColor: "#fff",
    borderRadius: "46px",
    // width: "800px",
    pt: { xl: 1, lg: 0, md: 2, sm: 2, xs: 2 },
    pb: { xl: 3, lg: 1.5, md: 2, sm: 2, xs: 2 },
  },
  innerGetLoginBox: { maxWidth: "100%", maxHeight: "100%" },
  signBtn: {
    width: "100%",
    background: "#9178e3",
    borderRadius: "8px",
    color: "#000",
    fontSize: "18px !important",
    fontWeight: 500,
    fontFamily: "Verdana !important",
    "&:hover": {
      background: "#9178e3",
    },
  },
  inputLabel: {
    fontWeight: 600,
    color: "#000 !important",
    "&.Mui-focused": {
      border: "2px solid red",
      "& .MuiOutlinedInput-notchedOutline": {
        border: "none",
      },
    },
  },
  textHeading1: {
    color: "#000",
    lineHeight: "50px",
    mt: 1,
  },
  heading5: {
    color: "#000",
    textAlign: "center",
    fontFamily: "Source Sans 3",
    fontStyle: "normal",
    fontWeight: "400",
    lineHeight: "23px",
    display: "inline",
  },
  heading6: {
    textAlign: "center",
    fontFamily: "Source Sans 3",
    fontStyle: "normal",
    fontWeight: "400",
    lineHeight: "23px",
    color: "#7A81FD",
    textDecoration: "underline",
    cursor: "pointer",
  },
} as const;

export default registerStyles;
