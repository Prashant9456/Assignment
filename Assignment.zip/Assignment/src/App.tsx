import React from "react";
import { ThemeProvider } from "@mui/material/styles";
import { useAppSelector } from "./hooks";
import { Router, Switch, Route } from "react-router-dom";
import { selectAuthenticated } from "./redux/authSlice";
import Layout from "./Layout/Layout";
import { themes } from "./Utils/Styles"; // Removed customTypography import
import PageNotFound from "./PageNotFound/PageNotFound";
import history from "./Utils/history";
import LandingPage from "./LandingPage/Landing";
import { Box } from "@mui/material";

const App = () => {
  const url = window.location.href;
  const isAuthenticated = useAppSelector(selectAuthenticated);
  return (
    <ThemeProvider theme={themes}>
      <Box>
        <Router history={history}>
          <Switch>
            <Route
              exact
              path={["/", "/login", "/register"]}
              component={LandingPage}
            />
            <Route path="/dashboard" component={Layout} />
            <Route path="*" component={PageNotFound} />
          </Switch>
        </Router>
      </Box>
    </ThemeProvider>
  );
};

export default App;
