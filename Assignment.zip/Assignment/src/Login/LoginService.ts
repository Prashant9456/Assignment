import { getCallParams, makeCall } from "../Service";
export async function login(email: any, password: any) {
  try {
    const callParams = getCallParams("POST", {
      email,
      password,
    });
    const response: any = await makeCall(
      "https://reqres.in/api/login",
      callParams
    );
    return response;
  } catch (error: any) {
    throw error;
  }
}
