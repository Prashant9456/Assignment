import { useEffect, useRef, useState } from "react";
import React from "react";
import { useAppDispatch } from "../hooks";
import { loginAction } from "../redux/authSlice";
import {
  Box,
  Typography,
  Grid,
  FormHelperText,
  InputAdornment,
  IconButton,
} from "@mui/material";
import history from "../Utils/history";
import { isTruthy } from "../Utils/methods";
import CustomInput from "../Components/CustomInput/CustomInput";
import CustomButton from "../Components/CustomButton/CustomButton";
import { loginForm, loginValidation } from "./LoginTypeValidation";
import loginStyles from "./LoginStyle";
import { login } from "./LoginService";

const Login = () => {
  const classes = loginStyles;
  const emailRegex =
    /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  const dispatch = useAppDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [formFields, setFormFields] = useState(loginForm);
  const [isLoginInProgress, setIsLoginInProgress] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const url = window.location.href;
  const componentRef = useRef<any>(null);

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (
        componentRef.current &&
        !componentRef.current.contains(event.target)
      ) {
        setIsLoading(false);
      }
    };

    document.addEventListener("click", handleClickOutside);

    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  const handleOnChangeInputField = (event: React.ChangeEvent<any>) => {
    setFormFields({
      ...formFields,
      [event.target.name]: {
        ...formFields[event.target.name],
        value: event.target.value,
      },
    });
  };
  const handleLogin = async () => {
    try {
      if (
        handleValidation() &&
        emailRegex.test(formFields.email.value) &&
        formFields.email.value.length > 0 &&
        !isLoginInProgress
      ) {
        setIsLoginInProgress(true);
        const email = formFields.email.value.toLowerCase();
        const password = formFields.password.value;
        setIsLoading(true);
        const user = await login(email, password);

        dispatch(
          loginAction({
            authenticated: true,
            accessToken: user.token,
          })
        );

        setIsLoading(false);
        setIsLoginInProgress(false);
      }
    } catch (error: any) {
      setIsLoading(false);
      alert(error?.error);
    }
  };

  const registerPage = () => {
    history.push("/register");
  };

  const handleKeypress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleLogin();
    }
  };

  const handleValidation = () => {
    const { isValid, errors } = loginValidation(formFields);
    setFormFields({ ...errors });
    return isValid;
  };

  const getLoginScreen = () => {
    return (
      <Box sx={classes.getLoginScreen} ref={componentRef}>
        <Box sx={classes.innerGetLoginBox}>
          <Typography sx={classes.getHeading} variant="h1">
            Sign In
          </Typography>
          <Box sx={{ textAlign: "center" }} mt={1}>
            <Typography sx={classes.heading5} variant="h5">
              Hey, You don't have an account yet?{" "}
              <Typography
                sx={classes.heading6}
                component={"span"}
                variant="h5"
                onClick={registerPage}
              >
                Sign up
              </Typography>
            </Typography>
          </Box>
          <Box>
            <Box>
              <Grid
                container
                sx={classes.formCenter}
                mt={{ xl: 5, lg: 1, md: 1, sm: 0.5, xs: 0.5 }}
              >
                <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
                  <CustomInput
                    required
                    label="Email"
                    placeHolder="Enter email address"
                    id="email"
                    type="email"
                    name="email"
                    value={formFields.email.value}
                    onChange={handleOnChangeInputField}
                    onKeyPress={handleKeypress}
                    customClasses={classes.inputLabel}
                    customInputClasses={classes.inputstyle}
                    error={
                      !isTruthy(formFields.email.value) &&
                      formFields.email.error
                    }
                  />
                  {!isTruthy(formFields.email.value) &&
                    formFields.email.error && (
                      <FormHelperText error>
                        {formFields.email.error}
                      </FormHelperText>
                    )}
                  {!emailRegex.test(formFields.email.value) &&
                    formFields.email.value.length > 0 && (
                      <FormHelperText error>
                        Please enter valid email id
                      </FormHelperText>
                    )}
                </Grid>
                <Grid item xs={11} sm={11} md={11} lg={11} xl={11} mt={2}>
                  <CustomInput
                    required
                    label="Password"
                    placeHolder="••••••••"
                    id="password"
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={formFields.password.value}
                    onChange={handleOnChangeInputField}
                    onKeyPress={handleKeypress}
                    customClasses={classes.inputLabel}
                    customInputClasses={{
                      ...classes.inputstyle,
                      "& input::-ms-reveal": { display: "none" },
                    }}
                    error={
                      !isTruthy(formFields.password.value) &&
                      formFields.password.error
                    }
                  />
                  {!isTruthy(formFields.password.value) &&
                    formFields.password.error && (
                      <FormHelperText error>
                        {formFields.password.error}
                      </FormHelperText>
                    )}
                </Grid>
                <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
                  <Box sx={classes.buttonWrapper}>
                    <CustomButton
                      label={
                        <Typography variant="h6" sx={classes.signInText}>
                          Sign In
                        </Typography>
                      }
                      onClick={handleLogin}
                      disabled={isLoading}
                      loading={isLoading}
                      customClasses={classes.signBtn}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Box>
      </Box>
    );
  };

  return <Box sx={classes.mainLoginWrapper}>{getLoginScreen()}</Box>;
};

export default Login;
