const loginStyles = {
  mainLoginWrapper: {
    height: "100%",
    width: "100%",
    marginTop: "25%",
  },
  inputstyle: {
    borderRadius: "12px",
    width: "100%",
    input: {
      "&:-webkit-autofill": {
        transition: "background-color 5000s ease-in-out 0s !important",
        "-webkit-text-fill-color": "#000 !important",
      },
    },
    // for placeholder style at disbled button
    "& .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input.Mui-disabled": {
      "-webkit-text-fill-color": "#000",
    },
    ".MuiOutlinedInput-notchedOutline": { border: "none" },
    "&.MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "& .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root": {
      color: "#000",
    },
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        color: "#000",
        fontSize: "15px",
        lineHeight: "28px",
      },
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: "38px",
      color: "#000",
      fontColor: "#000",
      fontSize: "14px",
      lineHeight: "1.5715",
    },
  },
  getLoginScreen: {
    backgroundColor: "#fff",
    borderRadius: "46px",
    pt: { xl: 3, lg: 3, md: 4, sm: 4, xs: 4 },
    pb: { xl: 3, lg: 2, md: 3, sm: 3, xs: 3 },
  },

  innerGetLoginBox: {
    maxWidth: "100%",
    maxHeight: "100%",
  },
  buttonWrapper: {
    mt: { xl: 6, lg: 4, md: 4, sm: 4, xs: 4 },
    width: "100%",
  },
  signInText: {
    fontWeight: 600,
    textAlign: "center",
    fontStyle: "normal",
    color: "#000",
    lineHeight: "23px",
  },
  signBtn: {
    width: "100%",
    background: "#9178e3",
    borderRadius: "8px",
    color: "#000",
    fontSize: "18px !important",
    fontWeight: 500,
    fontFamily: "Verdana !important",
    "&:hover": {
      background: "#9178e3",
    },
  },
  getHeading: {
    width: "82%",
    color: "#000",
    margin: "0 auto",
    lineHeight: "51.26px",
    fontWeight: 700,
    fontFamily: "Source Sans 3",
    textAlign: "center",
    [`@media screen and (min-width: ${1200}px)`]: {
      fontSize: "32px",
    },
  },

  formCenter: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  heading5: {
    color: "#000",
    textAlign: "center",
    fontFamily: "Source Sans 3",
    fontStyle: "normal",
    fontWeight: "400",
    lineHeight: "23px",
    display: "inline",
  },
  heading6: {
    textAlign: "center",
    fontFamily: "Source Sans 3",
    fontStyle: "normal",
    fontWeight: "400",
    lineHeight: "23px",
    color: "#7A81FD",
    textDecoration: "underline",
    cursor: "pointer",
  },

  inputLabel: {
    fontWeight: 600,
    color: "#000 !important",
    "&.Mui-focused": {
      border: "2px solid red",
      "& .MuiOutlinedInput-notchedOutline": {
        border: "none",
      },
    },
  },
} as const;

export default loginStyles;
