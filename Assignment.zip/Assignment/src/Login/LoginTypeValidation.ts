export const loginForm = () => {
  return {
    email: {
      value: "",
      error: "",
    },
    password: {
      value: "",
      error: "",
    },
  } as any;
};

export const loginValidation = (loginUserData: any) => {
  let errors = loginUserData;
  let isValid = true;
  const email = loginUserData.email.value;
  const password = loginUserData.password.value;
  if (!email) {
    errors.email.error = "Please enter your email id";
    isValid = false;
  }
  if (!password) {
    errors.password.error = "Please enter your password";
    isValid = false;
  }
  return { isValid, errors };
};
