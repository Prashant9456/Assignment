import { Box, Button, SxProps, TextField, Typography } from "@mui/material";
import { store } from "../store";
import { logOutAction } from "../redux/authSlice";
const Dashboard = () => {
  const logOutButton = () => {
    return (
      <>
        <Button
          variant="contained"
          onClick={() => {
            store.dispatch(logOutAction());
          }}
        >
          LogOut
        </Button>
      </>
    );
  };
  const getDashboardData = () => {
    return (
      <>
        {logOutButton()}
        <Box>Dashboard</Box>
      </>
    );
  };
  return getDashboardData();
};
export default Dashboard;
