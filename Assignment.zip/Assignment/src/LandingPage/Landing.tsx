import React, { useEffect } from "react";
import { Grid } from "@mui/material";
import { useHistory } from "react-router-dom";
import { useAppSelector } from "../hooks";
import { selectAuthenticated } from "../redux/authSlice";
import Login from "../Login/Login";
import Register from "../Register/Register";
import landingPageStyles from "./LandingPage.styles";

interface CustomProps {
  location?: Location;
}

const LandingPage: React.FC<CustomProps> = (props) => {
  const classes = landingPageStyles;
  const isAuthenticated = useAppSelector(selectAuthenticated);
  const history = useHistory();

  const getComponentBasedOnURL = () => {
    const location = props.location?.pathname?.split("/")[1]?.toLowerCase();
    switch (location) {
      case "login":
        return <Login />;
      case "register":
        return <Register />;
      default:
        return <Login />;
    }
  };

  const getLandingPage = () => (
    <Grid container sx={classes.mainWrapper}>
      <Grid
        item
        xl={12}
        lg={12}
        md={12}
        sm={12}
        xs={12}
        sx={classes.getComponentBasedOnURLWrapper}
      >
        <Grid container sx={classes.innerWrapper}>
          <Grid item xl={3.4} lg={4.5} md={6} sm={9} xs={10}>
            {getComponentBasedOnURL()}
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );

  useEffect(() => {
    if (isAuthenticated) {
      history.push("/dashboard");
    }
  }, [isAuthenticated, history]);

  return getLandingPage();
};

export default LandingPage;
