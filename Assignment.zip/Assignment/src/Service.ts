export const getCallParams = (methodType: string, body?: any) => {
  return {
    method: methodType,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
};

export function getTimeoutPromise() {
  return new Promise((resolve, reject) => {
    setTimeout(() => reject({ error: true, message: "Timeout" }), 200000);
  });
}

export const makeCall = async (callName: string, callParams: any) => {
  try {
    let call = fetch(callName, callParams);
    let timeout = getTimeoutPromise();

    const response: any = await Promise.race([timeout, call]).catch((error) => {
      throw error;
    });

    const json = await response.json();
    if (response && response.ok) {
      return json;
    }
    throw json;
  } catch (error: any) {
    throw error;
  }
};
