import React, { useEffect, useRef, useState } from "react";
import { Box, useMediaQuery } from "@mui/material";
import { Switch } from "react-router";
import { useAppDispatch, useAppSelector } from "../hooks";
import { selectAuthenticated } from "../redux/authSlice";
import PrivateRoute from "../Components/PrivateRoute/PrivateRoute";
import Login from "../Login/Login";
import Register from "../Register/Register";
import { Route } from "react-router-dom";
import Dashboard from "../Dashboard/Dashboard";
import PageNotFound from "../PageNotFound/PageNotFound";

const Layout = () => {
  const dispatch = useAppDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const isAuthenticated = useAppSelector(selectAuthenticated);

  const getContent = () => {
    return (
      <>
        <Switch>
          <PrivateRoute
            exact
            isLoggedIn={isAuthenticated}
            path={"/dashboard"}
            component={Dashboard}
          />
        </Switch>
      </>
    );
  };

  return getContent();
};
export default React.memo(Layout);
