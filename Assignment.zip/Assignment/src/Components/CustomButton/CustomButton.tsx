import React from "react";
import { Button, Typography } from "@mui/material";
import CircularProgress from "@mui/material/CircularProgress";
import customButtonStyles from "./CustomButton.styles";

type Props = {
  label?: string | JSX.Element;
  onClick: any;
  loading?: boolean;
  customClasses?: any;
  icon?: JSX.Element;
  disabled?: boolean;
  buttonType?: string;
};

const CustomButton: React.FC<Props> = ({
  label,
  onClick,
  customClasses,
  disabled,
  icon,
  loading,
  buttonType,
}) => {
  const classes = customButtonStyles;

  const processing = loading ? loading : false;
  const btnDisabled = disabled ? disabled : false;

  const getCustomCss = () => {
    switch (buttonType) {
      case "outlined":
        return classes.outlinedBtn;
      case "contained":
        return classes.containedBtn;
      default:
        return {};
    }
  };

  const switchButtonType = getCustomCss();
  const appliedClasses = {
    ...classes.btnStyle,
    ...switchButtonType,
    ...(customClasses ?? {}),
  };
  return (
    <Button
      startIcon={icon}
      sx={[appliedClasses]}
      onClick={(event: any) => onClick(event)}
      disabled={processing || disabled}
    >
      {processing ? (
        <CircularProgress sx={classes.loadingStyle} />
      ) : (
        <Typography variant="h5" sx={classes.buttonTextStyle}>
          {label}
        </Typography>
      )}
    </Button>
  );
};

export default CustomButton;
