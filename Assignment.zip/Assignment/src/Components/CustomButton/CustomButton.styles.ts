const customButtonStyles = {
  btnStyle: {
    width: "80%",
    fontFamily: "Verdana !important",
    padding: "10px 20px",
    "&:disabled": {
      color: "#000",
    },
  },
  glydeGif: {
    width: "15px",
    height: "15px",
  },
  loadingStyle: {
    color: "white",
    width: "25px !important",
    height: "25px !important",
  },
  outlinedBtn: {
    borderRadius: "34px",
    textAlign: "center",
    background: "#9178e3",
    fontStyle: "normal",
    fontWeight: 600,
    fontFamily: "Poppins",
    "&:hover": {
      background: "#9178e3",
    },
  },

  buttonTextStyle: {
    fontFamily: "Source Sans 3",
    fontStyle: "normal",
    fontWeight: 400,
    fontSize: "14px",
    lineHeight: "20px",
    /* identical to box height */

    color: "$FFFFFF",
  },
  containedBtn: {
    borderRadius: "34px",
    textAlign: "center",
    fontStyle: "normal",
    fontWeight: 600,
    fontFamily: "Poppins",
  },
};

export default customButtonStyles;
