import React from "react";
import { Route, Redirect, RouteProps } from "react-router-dom";

interface CustomProps extends RouteProps {
  component: React.ComponentType<any>;
  isLoggedIn: boolean;
}

const PrivateRoute: React.FC<CustomProps> = ({
  component: Component,
  isLoggedIn,
  ...rest
}) => {
  return (
    <Route
      {...rest}
      render={(routeProps) =>
        isLoggedIn ? (
          <Component {...routeProps} />
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: { from: routeProps.location },
            }}
          />
        )
      }
    />
  );
};

export default PrivateRoute;
