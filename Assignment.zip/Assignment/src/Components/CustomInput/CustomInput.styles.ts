const customInputStyles = {
  textFieldLight: {
    borderRadius: "38px",
    curetColor: "white",
    background: "#c5e8e2",
    width: "100%",
    "& .MuiOutlinedInput-root": {
      borderRadius: "38px",
      color: "red",
      fontColor: "#000",
      fontSize: "14px",
      lineHeight: "1.5715",
    },
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      color: "#7A7A7A",
      fontSize: "16px",
      lineHeight: "28px",
      fontFamily: "Source Sans 3",
      "&::placeholder": {
        fontFamily: "Source Sans 3",
        color: "#000",
        fontSize: "16px",
        lineHeight: "28px",
      },
    },
    input: {
      "&:-webkit-autofill": {
        WebkitBoxShadow: ` 0 0 0 1000px #c5e8e2 inset`,
        transition: "background-color 5000s ease-in-out 0s !important",
        backgroundColor: "#c5e8e2 ! important",
        "-webkit-text-fill-color": "#7A7A7A !important",
      },
    },
    "&.MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "& .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root": {
      color: "#ffffff",
    },
    // for placeholder style at disbled button
    "& .Mui-disabled": {
      "& .MuiInputBase-input.MuiOutlinedInput-input": {
        "-webkit-text-fill-color": "#000",
      },
    },
    ".MuiOutlinedInput-notchedOutline": { border: "none" },
  },
  textField: {
    borderRadius: "38px",
    curetColor: "black",
    width: "100%",
    "& .MuiOutlinedInput-root": {
      borderRadius: "38px",
      color: "#BEBEBE",
      fontColor: "#000",
      fontSize: "14px",
      lineHeight: "1.5715",
    },
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        color: "#000",
        fontSize: "15px",
        lineHeight: "28px",
      },
    },
    input: {
      "&:-webkit-autofill": {
        transition: "background-color 5000s ease-in-out 0s !important",
        "-webkit-text-fill-color": "#fff !important",
      },
    },
    ".MuiOutlinedInput-notchedOutline": { border: "none" },
    "&.MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "& .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root": {
      color: "#ffffff",
    },
    // for placeholder style at disbled button
    "& .Mui-disabled": {
      "& .MuiInputBase-input.MuiOutlinedInput-input": {
        "-webkit-text-fill-color": "#000",
      },
    },
  },
  errorStyle: {
    fontSize: "0.75rem",
    color: "#d32f2f",
  },
  nameField: {
    fontWeight: 500,
    color: "#ffffff",
    marginLeft: "4px",
    display: "flex",
    "& .MuiFormLabel-asterisk": {
      fontSize: "11px",
    },
  },
  nameField1: {
    fontWeight: 500,
    color: "#000000",
    marginLeft: "4px",
    display: "flex",
    "& .MuiFormLabel-asterisk": {
      fontSize: "11px",
    },
  },
} as const;

export default customInputStyles;
