import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../store";

export interface AuthState {
  authenticated: boolean;
  accessToken: string;
}
// localStorage.clear();
const initialState: AuthState = {
  authenticated: false,
  accessToken: "",
};

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    loginAction: (
      state,
      action: PayloadAction<{
        authenticated: boolean;
        accessToken: string;
      }>
    ) => {
      state.authenticated = action.payload.authenticated;
      state.accessToken = action.payload.accessToken;
    },

    logOutAction: (state, action: {}) => {
      localStorage.removeItem("_grecaptcha");
      localStorage.removeItem("state");
      sessionStorage.clear();
      if ("caches" in window) {
        // Clear cache storage
        caches.keys().then(function (cacheNames) {
          cacheNames.forEach(function (cacheName) {
            caches.delete(cacheName);
          });
        });
      }
      if ("cookies" in window) {
        // Clear cookies
        let cookies = document.cookie.split(";");

        for (var i = 0; i < cookies.length; i++) {
          var cookie = cookies[i];
          var eqPos = cookie.indexOf("=");
          var name = eqPos > -1 ? cookie.substring(0, eqPos) : cookie;
          document.cookie =
            name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
        }
      }
      state.authenticated = false;
      state.accessToken = "";
    },
  },
});

export const { loginAction, logOutAction } = authSlice.actions;
export const selectAuthenticated = (state: RootState) =>
  state.auth.authenticated;
export const selectAccessToken = (state: RootState) => state.auth.accessToken;

export default authSlice.reducer;
