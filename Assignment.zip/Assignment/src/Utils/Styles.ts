import { createTheme } from "@mui/material/styles";
const breakpoints: any = {
  values: {
    xs: 0,
    sm: 600,
    md: 900,
    lg: 1200,
    lg2: 1326,
    xl: 1536,
  },
};
const sournceSansFamily = "Source Sans 3";
const sansSerif = "sans-serif";
const regularFamily = "MyriadPro_Regular";
const customTypography = {
  typography: {
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      "MyriadPro_Light",
      "MyriadPro_Bold",
      "MyriadPro_Medium",
      "MyriadPro_Regular",
      "sans-serif",
      "Digital-7 Mono",
    ].join(","),
  },
  // for heading 24.8px to 20.8px
  h1: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "1.30rem", //20.8px
      fontWeight: 700,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "1.30rem", //20.8px
      fontWeight: 700,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "1.45rem", //23.2px
      fontWeight: 700,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "1.50rem", //24px
      fontWeight: 700,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1.625rem", //25.92px
      fontWeight: 700,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
  },
  // for 22px
  h2: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "1.063rem", //17px
      fontWeight: 600,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "1.188rem", //19.008px
      fontWeight: 600,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "1.25rem", //20px
      fontWeight: 600,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "1.313rem", //21.008px
      fontWeight: 600,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1.375rem", //22px
      fontWeight: 600,
      fontFamily:
        "Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,sans-serif",
    },
  },
  // 17.008px
  h3: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.938rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.938rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "1rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "1rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1.063rem",
      fontFamily: sournceSansFamily,
    },
  },
  // for table header 16px
  h4: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.91rem",
      // fontFamily: boldFamily,
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.92rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.94rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.94rem",
      fontFamily: sournceSansFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1rem",
      fontFamily: sournceSansFamily,
    },
  },
  // for table row 14px
  h5: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.781rem", //12.496px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.813rem", // 13px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "0.875rem", //14px
      fontFamily: "Verdana",
    },
  },
  // for input label //16px
  h6: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.813rem", //13.008
      fontFamily: "sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.875rem", //14px
      fontFamily: "sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "1rem", //16px
      fontFamily: "sans-serif",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1rem", //16px
      fontFamily: "sans-serif",
    },
  },
  // for normal text 16px
  body1: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.844rem",
      fontFamily: sansSerif,
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.875rem",
      fontFamily: sansSerif,
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.906rem",
      fontFamily: sansSerif,
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.938rem",
      fontFamily: sansSerif,
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "1rem",
      fontFamily: sansSerif,
    },
  },
  // stepper  14px
  body2: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.813rem",
      fontFamily: regularFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.844rem",
      fontFamily: regularFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.875rem",
      fontFamily: regularFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.906rem",
      fontFamily: regularFamily,
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "0.938rem",
      fontFamily: regularFamily,
    },
  },
  // for  14px
  subtitle1: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.813rem", //13px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.813rem", //13px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "0.875rem", // 14px
      fontFamily: "Verdana",
    },
  },

  subtitle2: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.563rem", //9px
      // lineHeight: 1.2,
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.625rem", //10px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.625rem", //10px
      fontFamily: "Verdana",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
      lineHeight: 1.2,
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "0.75rem", //12px
      fontFamily: "Verdana",
      lineHeight: 1.2,
    },
  },
  // for button 16px
  button: {
    [`@media screen and (min-width: ${breakpoints.values.xs}px)`]: {
      fontSize: "0.875rem",
      fontFamily: regularFamily,
      textTransform: "capitalize",
    },
    [`@media screen and (min-width: ${breakpoints.values.sm}px)`]: {
      fontSize: "0.875rem",
      fontFamily: regularFamily,
      textTransform: "capitalize",
    },
    [`@media screen and (min-width: ${breakpoints.values.md}px)`]: {
      fontSize: "0.813rem",
      fontFamily: regularFamily,
      textTransform: "capitalize",
    },
    [`@media screen and (min-width: ${breakpoints.values.lg}px)`]: {
      fontSize: "0.875rem",
      fontFamily: regularFamily,
      textTransform: "capitalize",
    },
    [`@media screen and (min-width: ${breakpoints.values.xl}px)`]: {
      fontSize: "0.938rem",
      fontFamily: regularFamily,
      textTransform: "capitalize",
    },
  },
  fontFamily: [
    "-apple-system",
    "BlinkMacSystemFont",
    "TT_Norms_Pro_Regular",
    "TT_Norms_Pro_Thin",
    "TT_Norms_Pro_Bold",
    "TT_Norms_Pro_Light",
    "TT_Norms_Pro_Medium",
    "sans-serif",
  ].join(","),
};
const themes = createTheme({
  // breakpoints,
  typography: {
    ...customTypography,
  },
});
const theme = createTheme({
  typography: {},
});

export { customTypography, themes, theme };
